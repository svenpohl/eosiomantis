
 
 
/*
          chainId: 'aca376f206b8fc25a6ed44dbdc66547c36c6c33e3a119ffbeaef943642f0e906',
          nodeUrl: 'https://eos.greymass.com'

*/

     const  transport = new AnchorLinkBrowserTransport()
      const link = new AnchorLink({
        chains: [{
          chainId: eosiomantis_chainid,
          nodeUrl: eosiomantis_nodeurl
        }],
         transport
      })

      async function load2() {
        const rows = await link.client.v1.chain.get_table_rows({
          code: 'eosio',
          scope: 'eosio',
          table: 'global',
        })
        const el = document.getElementById("example")
        el.innerHTML = JSON.stringify(rows)
      }

      // the EOSIO action we want to sign and broadcast
      const action = {
          account: 'eosio',
          name: 'voteproducer',
          authorization: [{
              actor: '............1', // ............1 will be resolved to the signing accounts permission
              permission: '............2' // ............2 will be resolved to the signing accounts authority
          }],
          data: {
              voter: '............1',
              proxy: 'greymassvote',
              producers: [],
          }
      }
      // ask the user to sign the transaction and then broadcast to chain
      function vote() {
          link.transact({action})
              .then((result) => {
                  document.body.innerHTML = `<h1>Thank you ${ result.signer.actor }!</h1>`
              })
      }

      
      
      
      
      
       // login
       const identifier = 'example2'
       
       let eosio_session

        // tries to restore session, called when document is loaded
        function restoreSession() {
            link.restoreSession(identifier).then((result) => {
                eosio_session = result
                if (eosio_session) {
                    didLogin()
                }
            })
        }

        // login and store session if sucessful
        function eosmantis_anchor_login() {
            link.login(identifier).then((result) => {
                eosio_session = result.session;
                
                console.log("SESSION:");                
                console.log(eosio_session);
                
               

     
                didLogin()
            })
        }

    
        function eosmantis_anchor_logout() {
 

                document.getElementById('login_button_anchor').style.visibility = 'visible';
                document.getElementById('login_button_anchor').style.height     = '60px';                
                document.getElementById('logout_button_anchor').style.visibility = 'hidden';
                document.getElementById('logout_button_anchor').style.height     = '0px';
                document.getElementById('account-name').style.height             = '0px';

         



  if (document.getElementById('account-name') )
           {
           document.getElementById('account-name').textContent = '';
           }
   
            eosio_session.remove()
        }

        // called when session was restored or created
        function didLogin() 
        {
        
         document.getElementById('login_button_anchor').style.visibility = 'hidden';
                document.getElementById('login_button_anchor').style.height     = '0px';                
                document.getElementById('logout_button_anchor').style.visibility = 'visible';
                document.getElementById('logout_button_anchor').style.height     = '60px';
                document.getElementById('account-name').style.height             = '';

 

        
        if (document.getElementById('account-name') )
           {
           document.getElementById('account-name').textContent = eosio_greeting + ' ' + eosio_session.auth.actor
           }
           document.body.classList.add('logged-in')
        }

 	

        // transfer tokens using a session
        function transfer() {
        
         var thetoken = eosiomantis_pay_amount + " " + eosiomantis_pay_token;
        
            const action = {
                account: eosiomantis_pay_contract,
                name: 'transfer',
                 authorization: [eosio_session.auth],
 
                data: {
                    from: eosio_session.auth.actor,
 
                    to: eosiomantis_pay_receiver,
                    quantity: thetoken,
                    memo: eosiomantis_pay_memo
                }
            }
            eosio_session.transact({action}).then((result) => 
            {
            
            document.getElementById('eosmantis_thankyou_content').style.visibility = 'visible';
            document.getElementById('eosmantis_thankyou_content').style.height = '';
            
           
            })
        }
        
        
        
async function get_balance_eos() {

 
const rows = await link.client.v1.chain.get_table_rows({
          code: 'eosio.token',
          scope: eosio_session.auth.actor,
          table: 'accounts',
        })

       
        console.log( JSON.stringify(rows) );
        console.log(rows.rows[0].balance);
         document.getElementById('account-balance-eos').innerHTML =  rows.rows[0].balance;

      }
              




function eosiomantis_thread()
{

if ( document.getElementById('account-balance-eos') )
   {
   get_balance_eos();
   }
 
var zeit = setTimeout("eosiomantis_thread()", 3000);
} //// eosiomantis_thread



eosiomantis_thread();      
        
        