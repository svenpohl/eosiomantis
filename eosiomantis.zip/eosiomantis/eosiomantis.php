<?php
/*
Plugin Name: eosiomantis
Plugin URI: http://www.zen-systems.de
Description: EOSIO tools for wordpress.
Version: 0.1
Author: Sven Pohl
Author URI: http://www.zen-systems.de
*/

define("EOSIOMANTIS_VERSION","0.01");


 

register_activation_hook( __FILE__, 'eosiomantis_activate' );

function eosiomantis_activate() 
{
$eosiomantis_chainid = get_option('eosiomantis_chainid');
$eosiomantis_nodeurl = get_option('eosiomantis_nodeurl');

if ( $eosiomantis_chainid == "" ) $eosiomantis_chainid = "aca376f206b8fc25a6ed44dbdc66547c36c6c33e3a119ffbeaef943642f0e906";
if ( $eosiomantis_nodeurl == "" ) $eosiomantis_nodeurl = "https://eos.greymass.com";


update_option('eosiomantis_chainid',$eosiomantis_chainid);
update_option('eosiomantis_nodeurl',$eosiomantis_nodeurl);
}



//////////////////////////////
//// Plugin-CSS laden
//////////////////////////////
add_action('wp_print_styles', 'eosiomantis_plugin_load');

 
 
 
 
 
function eosiomantis_plugin_load()
{
global $current_user;


$post_id = get_the_ID();
$eosiomantis_page_shortcode     = get_post_meta($post_id , 'eosiomantis_page_shortcode', true); 
 
 

if ( $eosiomantis_page_shortcode == 'on')
{

$csslink ="
<script src=\"https://unpkg.com/anchor-link@next\"></script>
<script src=\"https://unpkg.com/anchor-link-browser-transport@next\"></script>
";
echo $csslink;

$csslink = "\n<link rel='stylesheet' href='" .get_option( 'siteurl' ) . '/'  .PLUGINDIR ."/eosiomantis/css/style.css'>\n";
echo $csslink;



$eosiomantis_chainid = get_option('eosiomantis_chainid');
$eosiomantis_nodeurl = get_option('eosiomantis_nodeurl');

$content = "";
$content .= "<script>";
$content .= "var eosiomantis_chainid='".$eosiomantis_chainid."';";
$content .= "var eosiomantis_nodeurl='".$eosiomantis_nodeurl."';";
$content .= "</script>";
print($content);



$javalink = "\n<script src='" .get_option( 'siteurl' ) . '/'  .PLUGINDIR ."/eosiomantis/js/eosiomantis.js' type='text/javascript'></script>\n";
echo $javalink;




 
} // if ( $eosiomantis_page_shortcode == 'on')

} // function eosiomantis_plugin_load()



//
// Add restoreSession() to the end of content
// 
if( !function_exists("eosiomantis_bottom_of_every_post")){
	function eosiomantis_bottom_of_every_post($content)
	{
    $content .= "<script>";
	$content .= "restoreSession();";
	$content .= "</script>";
	return $content;
	}
}



add_filter('the_content', 'eosiomantis_bottom_of_every_post');
	

/////////////////////////////////////////////
////
//// [eos_anchor] shortcode 
////
/////////////////////////////////////////////
if( !function_exists('func_eos_anchor') ) 
 {
	function func_eos_anchor($atts) 
	{
	
	$post_id = get_the_ID();
    $eosiomantis_page_shortcode     = get_post_meta($post_id , 'eosiomantis_page_shortcode', true); 
 
 

    if ( $eosiomantis_page_shortcode != 'on')
    {
    $content = "[ERROR - Please enable EOSIO-resources for this page!]";
    return($content);
    }

	
	// Init
	$plugins_url = plugins_url(); 
	 
	
	
	$content = "";
	
	
	$image = $plugins_url . "/eosiomantis/img/anchor.png";
   
    $content .= "<div id='login_button_anchor' onclick='eosmantis_anchor_login()' class='login_button_anchor' >";
    $content .= "<img src='".$image."' class='login_button_anchor_image' >";
	$content .= "</div>";


	$image_logout = $plugins_url . "/eosiomantis/img/anchor_logout.png";

    $content .= "<div id='logout_button_anchor' onclick='eosmantis_anchor_logout()' class='login_button_anchor logout_button_anchor'  >";
    $content .= "<img src='".$image_logout."' class='login_button_anchor_image' >";
	$content .= "</div>";
	


    $content .= $content2;

   
	return $content;
	} //// func_sv_core_css
	
	add_shortcode("eos_anchor", "func_eos_anchor");
} //// if func_eos_anchor



/////////////////////////////////////////////
////
//// [eos_accountname] shortcode 
////
/////////////////////////////////////////////
if( !function_exists('func_eos_accountname') ) 
 {
	function func_eos_accountname($atts) 
	{
	
	$greeting = $atts['greeting'];

	$content .= "<script>";
	$content .= "var eosio_greeting = '".$greeting."';";
	$content .= "</script>";
	
    $content .= "<span id=\"account-name\" class=\"account-name\"></span>";
   
	return $content;
	} //// func_eos_accountname
	
	add_shortcode("eos_accountname", "func_eos_accountname");
} //// if func_eos_accountname




 
/////////////////////////////////////////////
////
//// [eos_balance] shortcode 
////
/////////////////////////////////////////////
if( !function_exists('func_eos_balance') ) 
 {
	function func_eos_balance($atts) 
	{
	
	$contract = $atts['contract'];
	$token    = $atts['token'];
	$token_small = strtolower($token);

    $content .= "<span id=\"account-balance-".$token_small."\" name=\"account-balance\" class=\"account-balance\"></span>";
   
	return $content;
	} //// func_eos_accountname
	
	add_shortcode("eos_balance", "func_eos_balance");
} //// if func_eos_balance


/////////////////////////////////////////////
////
//// [eos_donator] shortcode 
////
/////////////////////////////////////////////
if( !function_exists('func_eos_donator') ) 
 {
	function func_eos_donator($atts) 
	{
	
	if ( isset($atts['contract'])      )  $contract   = trim($atts['contract']  );
	if ( isset($atts['token'] )        )  $token      = trim($atts['token']     );
	if ( isset($atts['receiver'] )     )  $receiver   = trim($atts['receiver']     );
	if ( isset($atts['amount'] )       )  $amount     = trim($atts['amount']     );
	if ( isset($atts['amountlist'] )   )  $amountlist = trim($atts['amountlist']     );
	if ( isset($atts['buttontext'] )   )  $buttontext = trim($atts['buttontext']);
	if ( isset($atts['memo']       )   )  $memo       = trim($atts['memo']);
	if ( $buttontext == "" )  $buttontext = "Transfer";
	 
	$plugins_url = plugins_url(); 
	 
 
	
	$content = "";
	
	
    $content .= "<script>";
	$content .= "var eosiomantis_pay_contract = '".$contract."';";
	$content .= "var eosiomantis_pay_token    = '".$token."';";
	$content .= "var eosiomantis_pay_receiver = '".$receiver."';";
	$content .= "var eosiomantis_pay_amount   = '".$amount."';";
	$content .= "var eosiomantis_pay_memo     = '".$memo."';";
	
	
	$content .= "function eosiomantis_chance_amount( value )";
	$content .= "{";
	 
 
     $content .= "eosiomantis_pay_amount = value;";
 
	
	$content .= "}";
	
	$content .= "</script>";
	
	
	 
	
 
	  
	// $content .= "(".$token.") (".$contract.")  (".$receiver.")   (".$amount.")  (".$amountlist.")  (".$memo.") ";
	
	$content .= "
    
    
    <div class='eosiomantis_donation_div'>
    ";
    
    
    $content .= "";
    
    $thearray = explode(";",$amountlist);
    $size = count($thearray);

    $content .= "<select id='eosio_donation_amounts' name='eosio_donation_amounts' onchange='eosiomantis_chance_amount(this.value)' >";

    
    $content2 = "";
    for ($i=0; $i<$size; $i++)
        {
        $value = $thearray[$i];
        $content2 .= "<option value='".$value."'>".$value." ".$token."</option>"; 
        
        } // for i...
    $content .= $content2;
    
    $content .= "</select>"; 

    $content .= "<br><br>";    
    
    $content2 = "
     <button  class='eosiomantis_donation_button' onclick=\"transfer()\">".$buttontext."</button>
    
  
    
    </div>
    
";	
 
$content .= $content2;


 
 
   
	return $content;
	} //// func_eos_donator
	
	add_shortcode("eos_donator", "func_eos_donator");
} //// if func_eos_donator



/////////////////////////////////////////////
////
//// [eos_donator_thankyou_content_begin] shortcode 
////
/////////////////////////////////////////////
if( !function_exists('func_eos_donator_thankyou_content_begin') ) 
 {
	function func_eos_donator_thankyou_content_begin($atts) 
	{
 

    $content .= "<div id='eosmantis_thankyou_content' style='visibility:hidden;height:0px;'>";
   
	return $content;
	} //// func_eos_accountname
	
	add_shortcode("eos_donator_thankyou_content_begin", "func_eos_donator_thankyou_content_begin");
} //// if func_eos_donator_thankyou_content_begin


/////////////////////////////////////////////
////
//// [eos_donator_thankyou_content_end] shortcode 
////
/////////////////////////////////////////////
if( !function_exists('func_eos_donator_thankyou_content_end') ) 
 {
	function func_eos_donator_thankyou_content_end($atts) 
	{
 

    $content .= "</div>";
   
	return $content;
	} //// func_eos_accountname
	
	add_shortcode("eos_donator_thankyou_content_end", "func_eos_donator_thankyou_content_end");
} //// if func_eos_donator_thankyou_content_end


 
 
////////////////////////////////////////////////////////////////
////
//// Erweitertes- Page-Menu
////
////////////////////////////////////////////////////////////////

 
add_action( 'add_meta_boxes', 'eosiomantis_add_custom_box' );
add_action( 'add_meta_boxes_page', 'eosiomantis_add_custom_box' );
add_action( 'save_post', 'eosiomantis_save_postdata' );

 
////////////////////////////////
////
//// @brief 
////
////////////////////////////////
function eosiomantis_add_custom_box() 
{
    add_meta_box( 
        'myplugin_sectionid2',
        __( 'EosioMantis', 'eosiomantis_textdomain' ),
        'eosiomantis_inner_custom_box',
        'post' 
    );

   
    
    
     
    
    
  
    
    add_meta_box(
       'myplugin_sectionid',
        __( 'EosioMantis', 'eosiomantis_textdomain' ),
        'eosiomantis_inner_custom_box',
        'page' 
    );

    add_meta_box(
 'myplugin_sectionid',
        __( 'EosioMantis', 'eosiomantis_textdomain' ),
        'eosiomantis_inner_custom_box',
        'full-width'
    );
    
     add_meta_box( 
        'myplugin_sectionid3',
        'EosioMantis',
        'eosiomantis_inner_custom_box',
        'post',
        'normal',
        'high' 
    );
    
} //// sp_app_add_custom_box







 
function eosiomantis_inner_custom_box( $post ) 
{

  // Use nonce for verification
   wp_nonce_field( plugin_basename( __FILE__ ), 'eosiomantis_noncename' );


  $post_id = get_the_ID();

  $eosiomantis_page_shortcode     = get_post_meta($post_id , 'eosiomantis_page_shortcode', true); 
 
 
print("<label>");
//print("<input type='text' name='sp_app_page_shortcode' style='width: 200px; ' value='".$sp_app_page_shortcode."'>");

if ( $eosiomantis_page_shortcode == 'on')
   print("<input type='checkbox' name='eosiomantis_page_shortcode' checked style='' value='on'>"); else
   print("<input type='checkbox' name='eosiomantis_page_shortcode'         style='' value='on'>"); 

print(" <strong>include EOSIO resources (css/javascript) for this page</strong> ");


print("</label><br>");
print("<br>");


	  
} //// eosiomantis_inner_custom_box



 
function eosiomantis_save_postdata( $post_id ) 
{
  
  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
      return;

   

  if ( !wp_verify_nonce( $_POST['eosiomantis_noncename'], plugin_basename( __FILE__ ) ) )
      return;

  
  // Check permissions
  if ( 'page' == $_POST['post_type'] || 'post' == $_POST['post_type'] ) 
  {
    if ( !current_user_can( 'edit_page', $post_id ) )
        return;
  }
  else
  {
    if ( !current_user_can( 'edit_post', $post_id ) )
        return;
  }

  // OK, we're authenticated: we need to find and save the data

 
   
  $eosiomantis_page_shortcode = $_REQUEST['eosiomantis_page_shortcode']; 
  update_post_meta($post_id, 'eosiomantis_page_shortcode', $eosiomantis_page_shortcode); 
  
 
} /// sp_ap_save_postdata

 
////////////////////////////////////////////////////////////////
////
//// ENDE - extended page-menu
////
////////////////////////////////////////////////////////////////

 

 

//////////////////////////////
//// Admin menu
//////////////////////////////
add_action('admin_menu', 'eosiomantis_admin_menu');

///////////////////////////////////////////////////////////////////
// make the options function is the admin option page
///////////////////////////////////////////////////////////////////
function eosiomantis_admin_menu() 
{
  add_options_page(  'EOSIO Mantis Einstellungen', 
            'EOSIO Mantis', 
            8, 
            __FILE__, 
            'eosiomantis_adminpanel');
} //// eosiomantis_admin_menu




/////////////////////////////////////////////////////////////////
//  This code is run on the admin options page for this plugin
/////////////////////////////////////////////////////////////////
function eosiomantis_adminpanel() 
{
global $wpdb;

 
print("<br>");
print("<h3>EOSMANTIS - Einstellungen</h3>");
print("<small>Version: ".EOSIOMANTIS_VERSION."</small><br>");
print("Github <a href='https://github.com/svenpohl' target='_blank'>https://github.com/svenpohl</a> | e-mail <a href='mailto:sven.pohl@zen-systems.de' target='_blank'>sven.pohl@zen-systems.de</a> | donation  <a href='https://bloks.io/account/mantismantis' target='_blank'>mantismantis</a> <br>");
print("<br>");

 

$eosiomantis_chainid = get_option('eosiomantis_chainid');
$eosiomantis_nodeurl = get_option('eosiomantis_nodeurl');

    

//
// Save
//
if(isset($_REQUEST['submit_eosiomantis']))
  {
  $eosiomantis_chainid             = trim($_REQUEST["eosiomantis_chainid"]);
  $eosiomantis_nodeurl      = trim($_REQUEST["eosiomantis_nodeurl"]);
    
  update_option('eosiomantis_chainid',$eosiomantis_chainid);
  update_option('eosiomantis_nodeurl',$eosiomantis_nodeurl); 
  } //// submit_eosiomantis
  
  
  
$eosiomantis_chainid = get_option('eosiomantis_chainid');
$eosiomantis_nodeurl = get_option('eosiomantis_nodeurl');

 

print("
<form method='post' action=''>
<br>
<strong>ChainID (z.B. aca376f206b8fc25a6ed44dbdc66547c36c6c33e3a119ffbeaef943642f0e906 ):</strong><br>
<input name='eosiomantis_chainid' style='width: 600px;' value='".$eosiomantis_chainid."' ><br>

<br>
<strong>Node URL (z.B. https://eos.greymass.com ):</strong><br>
<input name='eosiomantis_nodeurl' style='width: 600px;' value='".$eosiomantis_nodeurl."' ><br>

 
<br>
<br>
");


print("<br>");


print("
<p class='submit'>
<input type='submit' class='button-primary' name='submit_eosiomantis'
value='Save' />
</p>
</form>
");
 
print("<br><br>"); 

print(
"
<h2>Example 1) A simple donation</h2>

<div style='background:#ffffff;'>
<code style='padding:10px;'>
Donate me some <em>EOS!</em> <br>

<div style='text-align:left'>  <br>
[eos_anchor] <br>
[eos_accountname greeting='Hello'] <br>
[eos_balance contract='eosio.token' token='EOS'  ] <br>

&nbsp;<br>
&nbsp;<br>
<em>To support me please donate via EOS!</em> <br>
[eos_donator contract='eosio.token' token='EOS' receiver='fivenovember' amountlist='0.0002;0.0003;0.1000;1.0000' amount='0.0002' buttontext='Donate' memo='Thank you!!!']
<br>
<br>
[eos_donator_thankyou_content_begin]<br>
 <h2 style='color:#333366;'>Thank you sooo much for your donation!!! 🌻</h2> <br>
[eos_donator_thankyou_content_end]<br>
 
</div><br>
 
</code>
</div>
"
);
 

} //// eosiomantis_adminpanel


 
